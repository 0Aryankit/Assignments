#include <stdio.h>

// Function to calculate simple interest
float cal_SI(float principal, float rate, float time)
{
    // Simple Interest formula: SI=(P*R*T)/100
    float SI=(principal*rate*time)/100;
    return SI;
}

void main() 
{
    // Variables to store principal, rate, and time
    float principal,rate,time;

    // Input principal, rate, and time from user
    printf("Enter principal amount: ");
    scanf("%f",&principal);

    printf("Enter rate of interest: ");
    scanf("%f",&rate);

    printf("Enter time (in years): ");
    scanf("%f",&time);

    // Call the function to calculate simple interest
    float interest = cal_SI(principal,rate,time);

    printf("Simple Interest: %.2f\n", interest);

}
