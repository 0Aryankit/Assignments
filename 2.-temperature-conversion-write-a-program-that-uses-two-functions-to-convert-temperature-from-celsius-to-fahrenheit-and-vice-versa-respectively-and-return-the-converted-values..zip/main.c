/* 2. Temperature Conversion: Write a program that uses two functions to convert
temperature from Celsius to Fahrenheit and vice versa,
respectively and return the converted values.
*/
#include <stdio.h>

// Function to convert Celsius to Fahrenheit
float cel_to_Fahret(float celsius) {
    return (celsius * 9.0 / 5.0) + 32.0;
}

// Function to convert Fahrenheit to Celsius
float fahret_to_cel(float fahret) 
{
    return (fahret-32.0)*5.0/9.0;
}

void main() {
    float temperature;

    // Get temperature in Celsius from keyboard
    printf("Enter temperature in Celsius: ");
    scanf("%f", &temperature);

    // Convert Celsius to Fahrenheit and display the result
    printf("%f Celsius is equal to %f Fahrenheit\n", temperature, cel_to_Fahret(temperature));
    
    printf(" \n");
    // Get temperature in Fahrenheit from keyboard
    printf("Enter temperature in Fahrenheit: ");
    scanf("%f", &temperature);

    // Convert Fahrenheit to Celsius and display the result
    printf("%f Fahrenheit is equal to %f Celsius\n", temperature, fahret_to_cel(temperature));

   
}
