// traversing of arrrey and average


#include <stdio.h>

int main()
{  int a ,temp=0;
  
    int num[13]={34,45,2,3,4,5,2,54,5,10,33,45,44};
    
    
    for(int i=0;i<13;i++)
    {
        printf("index and value are %d%d\n",a,num[i]);
         
        temp=temp+num[i];
         
    }   printf("average value= %d",temp/13);

    return 0;
}


