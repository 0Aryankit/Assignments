/* 8. Sum of Array Elements: Write a program to calculate and return
  the sum of elements of a 1-D array. 
*/

#include <stdio.h>

// Function to calculate the sum of array elements
int cal_sum(int arr[], int a)
{  
    int sum = 0;

    // Loop to calculate the sum
    for (int i = 0; i < a; ++i)
    {
        sum += arr[i];
    }

    return sum;
}

int main() 
{
    int a;

    // Get the size of the array from  keyboard
    printf("Enter the size of the array: ");
    scanf("%d", &a);

    // Check if the size is non-negative
    if (a < 0)
    {
        printf("Please enter a non-negative size.\n");
        return 1; // Exit with an error code
    }

    int arr[a];

    // Get elements of the array from keyboard
    printf("Enter %d elements of the array: \n",a);
    for (int i=0; i<a; ++i) {
        scanf("%d", &arr[i]);
    }

    // Calling function 
    printf("The sum of array elements is: %d\n",cal_sum(arr,a));

    return 0;
}
