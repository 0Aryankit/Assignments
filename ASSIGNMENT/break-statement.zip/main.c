//keep taking no. as input from user until user enters an odd number (hint: do while loop)
#include<stdio.h>
void main()
{
    int n;
    do{
    printf("Enter the number=");
    scanf("%d",&n);
    printf("%d\n",n);
    
    if (n%2!=0) //!= means not equal to
    {
        break;
    }

    }
    while(1); // 1 means always true
    printf("you enter an odd number");
}

