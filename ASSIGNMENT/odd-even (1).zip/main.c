
#include <stdio.h> // include is simple function

void printmn()  //  here it  is called function
{
    printf("Hello function \n");
    printf("Enter no.");
    int a;
    scanf("%d",&a);
    if (a%2==0)  
    { printf("No. is even \n");
    }
     else
     { printf("No. is odd \n");
    
}
}
  void main( )   // here it is calling function
  {
      printmn();
      
  }
