//For loop

/* for(initialisation; condition; update);
  {do something}  */
  
  
#include<stdio.h>
void main()
{
   //1st prgm

/*
    for(int i=1; i<=10; i++)  // i++ = i+1 and i is called iterator or counter
    {
        printf("Hello Aryan\n");
        
    }
*/  
  
  // 2nd prgm
 
 
   for(int i=1;i<=23; i++)  // i++  = post increment operator means first use then increase
   {                       // ++i  = pre increment first use then increase
      printf("%d\n",i);
       
   }

     // 3rd prgm  :loop counter can be float 

/*   for (float i=20;i>=1;i--) // i-- =(i-1) post decrement operator 
   {
       printf("%f\n",i);
   }

*/
    //4th prgm :loop counter can be character

/*   for(char ch='A';ch<='Z';ch++)
   {
       printf("%c\n",ch);
   }
*/
  // 5th prgm :infinite loop // Dangerous
  
/* for(double i=1; ;i++)
     {printf("%d\n",i);
     }

*/

}