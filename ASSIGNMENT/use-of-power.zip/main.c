#include<stdio.h>
#include<math.h>
int main()
{
    //use of pow
    float num,p;
    printf("Enter the number=");
    scanf("%f",&num);
    p=pow(num,num);
    printf("Required answer will be='%f'",p);
    
    return 0;
    
    
    
    
}
