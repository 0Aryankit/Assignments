#include<stdio.h>
void main()
{
int a,b,c;
char op;
printf("value a,b,c are:");
scanf("%d%d%d",&a,&b,&c);
printf("Enter operation:");
scanf(" %c",&op); //before %c space is required.

switch(op)
 { case'+':
    printf("sum is :%d",a+b+c);
    break;
    case'-':
    printf("diff. is :%d",a-b-c);
    break;
    case'*':
    printf("multipication is :%d",a*b*c);
    break;
     case'/':
    printf("divide is :%d",a/b);
    break;
    

 }
 }