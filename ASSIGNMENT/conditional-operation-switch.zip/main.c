#include<stdio.h>
void main()
{    char day;
    printf("Enter day: ");
    scanf("%c",&day);
   switch(day){
              case 'm' : printf("Monday");
                      break;
              case 't' : printf("Tuesday");
                      break;
              case 'w' : printf("Wednesday");
                      break;
              case 'T' : printf("Thursday");
                      break;
              case 'f' : printf("Friday");
                      break;
              case 's': printf("Saturday");
                      break;
    
              default:printf("Not a valid day");}
}