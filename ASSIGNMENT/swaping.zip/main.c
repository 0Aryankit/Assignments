# include<stdio.h>

  void main()
  {
    int c,d, a=10,b=5;
       printf("a is:%d \n",a);
       printf("b is:%d\n",b);
       c,d=Swapn(a,b);
        printf("c is:%d\n",c);
         printf("d is:%d\n",d);
       
  }
   
   int Swapn(int i,int j)
   {
      printf("i is:%d\n",i);  
       printf("j is:%d\n",j);
        
        int temp;
        temp=i;
        i=j;
        j=temp;
        return i,j;
       
       
       
   }