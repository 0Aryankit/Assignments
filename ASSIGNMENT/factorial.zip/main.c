//factorial values

#include<stdio.h>
void main()
{
 int n, sum=1;
  printf("Enter the number=");
  scanf("%d",&n);
 
 for(int i=n;i>=1;i--)
     {
         sum=sum*i;
        
     } 
    
     printf("%d",sum);
    
    
}
