// do while loop  means print at least one time then check the condition 
  
/*  do{
      do something
  } while(condition);  */
  
/* #include<stdio.h>
 int main()
 {
     int i=1;
     do{ printf("%d\n",i);
        i++; 
     } while(i<=5); // if condition is not true then it will print at least one time
     
 return 0;
     
 } */
 
 
 // prgm 1: print the sum of first n natural number where n=4; also print them in reverse
 // can also use for factorial
  #include<stdio.h>
 int main()
 { 
     int n,sum=0;
    printf("enter nth natural no.= ");
    scanf("%d",&n);
    
    
    for(int i=1; i<=n; i++ )
    {
      sum=sum + i;
    }
    printf("Sum=%d",sum);
 
  return 0;
     
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 