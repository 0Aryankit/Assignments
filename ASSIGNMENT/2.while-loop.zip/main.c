// while loop
 /* while(condition){
     doing something
 }  */
  // Print the number from 0 to n, if n is given by the user
 
 #include<stdio.h>
 void main()
{
     int n;
     printf("Enter the number= ");
     scanf("%d",&n);
     int i=1;
     while(i<=n)
     {
        printf("%d\n",i);
        i++;
     }
 }
