/* 5. Calculate Factorial using Loops: Write a program to calculate the 
factorial of a number using a for loop and return its value. 
*/

#include<stdio.h>
int main()
{
  int n, sum=1;
  printf("Enter the number=");
  scanf("%d",&n);
  
  // Check if n is non-negative
    if (n < 0)
      {
        printf("Factorial is not defined for negative numbers.\n");
        return 0; // Return 0 for negative numbers
      }
  // Calculating factorial using a for loop
    for(int i=n;i>=1;i--)
       {
         sum=sum*i;
       } 
       printf("%d",sum);
}

