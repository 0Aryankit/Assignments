/* 3. Sum of Natural Numbers: Given a positive integer n, write a program to 
 calculate and return the sum of natural numbers up to n using loops. 
*/
#include <stdio.h>

// Function to calculate the sum of natural numbers up to n
int sum_of_n_numb(int n)
{
    int sum = 0;
   // Loop to calculate the sum
    for (int i = 1; i <= n; i++)
    {
        sum += i;
    }

    return sum;
}

int main() 
{
    int n;
    // Get the value of n from keyboard
    printf("Enter a positive integer n: ");
    scanf("%d", &n);

    // Check if n is a positive integer
    if (n < 1)
    {
        printf("Please enter a positive integer.\n");
        return 1; // Exit with an error code
    }

    // result of the sum of natural numbers up to n
    printf("The sum of natural numbers up to %d is: %d\n", n, sum_of_n_numb(n));

    return 0;
}
