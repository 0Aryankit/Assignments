// creating a file
#include <stdio.h>
#include<stdlib.h>

int main()
{
  FILE * fp;
  fp=fopen("file.txt","w");
  fprintf(fp,"youtube\n"); 
  // second methode fputs("coding",fp);
  fclose(fp);

    return 0;
}
