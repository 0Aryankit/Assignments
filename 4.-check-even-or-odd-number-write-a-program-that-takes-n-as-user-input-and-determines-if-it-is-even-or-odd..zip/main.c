/* 4. Check Even or Odd Number: Write a program that takes n 
as user input and determines if it is even or odd. 
*/

#include <stdio.h> // include is simple function

int even_odd()  //  here it  is called function
{
    //input through keyboard
    printf("Enter the number = ");
    int a;
    scanf("%d",&a);
    
    // Check if n is a positive integer
    if(a<0)
    {
        printf("please enter positive number ");
        return 0;  // Exit with an error code
    }
   
    if (a%2==0)  
       { printf("Number is even \n");
       }
    else
       { printf("Number is odd \n");
       }
}
   void main( )   // here it is calling function
   {
      even_odd();
      
   }


